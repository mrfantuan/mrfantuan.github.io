#ifndef _CONSTANT_H_
#define _CONSTANT_H_

typedef enum FACTORYTag
{
	kFactory_A,
	kFactory_B
}FactoryEnum;

#endif